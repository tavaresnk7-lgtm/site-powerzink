import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Recycle, ShieldCheck, HeadsetIcon, Check } from 'lucide-react';

const bullets = [
  { icon: Recycle, title: 'Grupo VW — solidez empresarial', text: 'Parte de um conglomerado com mais de 20 anos nos segmentos imobiliário, frotas e industrial.' },
  { icon: ShieldCheck, title: 'Proteção comprovada', text: 'Resistência testada contra corrosão, névoa salina e ambientes extremos.' },
  { icon: HeadsetIcon, title: 'Suporte técnico especializado', text: 'Pós-venda real — acompanhamento técnico pós-aplicação, algo que grandes fornecedores não oferecem.' },
];

export default function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section id="sobre" className="relative py-24 lg:py-32 bg-bg-offwhite overflow-hidden">
      <div ref={ref} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Photo */}
          <motion.div initial={{ opacity: 0, x: -40 }} animate={isInView ? { opacity: 1, x: 0 } : {}} transition={{ duration: 0.7 }} className="relative">
            <div className="relative rounded-2xl overflow-hidden aspect-[4/3]">
              <img src="https://images.unsplash.com/photo-1567789884554-0b844b597180?w=800&q=80" alt="Tanques industriais com revestimento anticorrosivo" className="w-full h-full object-cover" loading="lazy" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent" />
              <div className="absolute inset-0 bg-pz-green/8 mix-blend-overlay" />
            </div>
            <div className="absolute -bottom-5 -right-5 sm:right-6 bg-white rounded-xl shadow-lg shadow-black/8 p-5 border border-graphite-100 max-w-[180px]">
              <div className="font-heading font-bold text-3xl text-pz-green leading-none">20+</div>
              <div className="text-xs text-graphite-400 mt-1.5 font-medium uppercase tracking-wide leading-tight">Anos no mercado industrial</div>
            </div>
          </motion.div>

          {/* Content */}
          <motion.div initial={{ opacity: 0, x: 40 }} animate={isInView ? { opacity: 1, x: 0 } : {}} transition={{ duration: 0.7, delay: 0.15 }}>
            <span className="eyebrow mb-6 inline-flex">Sobre a PowerZink</span>
            <h2 className="heading-display text-3xl sm:text-4xl lg:text-[2.75rem] mt-5 mb-6">
              MAIS DE DUAS DÉCADAS DE <span className="text-pz-green">EXCELÊNCIA INDUSTRIAL</span>
            </h2>
            <div className="space-y-4 text-graphite-500 leading-relaxed">
              <p>
                A <strong className="text-graphite font-semibold">PowerZink</strong> é a marca
                industrial do <strong className="text-graphite font-semibold">Grupo VW</strong>,
                conglomerado com mais de duas décadas de atuação nos segmentos imobiliário, frotas e industrial.
              </p>
              <p>
                Nascemos da necessidade de oferecer ao mercado{' '}
                <strong className="text-pz-green font-semibold">soluções industriais completas</strong> —
                não apenas tinta, mas serviço técnico, consultoria, formulação sob medida e pós-venda real.
              </p>
            </div>
            <div className="mt-8 space-y-4">
              {bullets.map((b, i) => (
                <div key={i} className="flex items-start gap-4">
                  <div className="icon-box mt-0.5"><b.icon size={20} strokeWidth={2} /></div>
                  <div>
                    <h4 className="font-semibold text-graphite text-[15px]">{b.title}</h4>
                    <p className="text-sm text-graphite-400 mt-0.5">{b.text}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-2">
              {['Grupo VW', 'Suporte Técnico', 'Produtos On-Demand', 'Pós-venda Real'].map((tag, i) => (
                <span key={i} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-graphite-50 text-graphite-500 text-xs font-medium border border-graphite-100">
                  <Check size={12} className="text-pz-green" />{tag}
                </span>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
